//
//  ViewController.swift
//  Talla_TravelBooking
//
//  Created by Divya Talla on 4/1/24.
//

import UIKit

class BookingViewController: UIViewController {

    @IBOutlet weak var travellerNameOL: UITextField!

    
    @IBOutlet weak var noOfTravellersOL: UITextField!
    
    
    @IBOutlet weak var cabinTypeOL: UITextField!
    
    var name = ""
    var travellers = 0
    var cost = 0.0
    var image = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      
    }

    @IBAction func bookNowButton(_ sender: Any) {
        
        
        name = travellerNameOL.text ?? ""
               travellers = Int(noOfTravellersOL.text ?? "0") ?? 0
               
               let travelClass = (cabinTypeOL.text ?? "").lowercased()
               //check the class and find the cost accordingly
               if travelClass == "economy" {
                   cost = Double(travellers) * 125
                   image = "economy"
               } else if travelClass == "luxury" {
                   cost = Double(travellers) * 200
                   image = "luxury"
               } else {
                   image = "no selected class"
               }
           }
           
           override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
               if segue.identifier == "resultSegue" {
                   let destination = segue.destination as! ResultViewController
                   destination.name = name
                   destination.travellers = travellers
                   destination.travelClass = cabinTypeOL.text ?? ""
                   destination.cost = cost
                   destination.image = image
               }
           }
       }
