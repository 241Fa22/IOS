//
//  TallaFile.swift
//  Talla_Exam3
//
//  Created by Divya Talla on 4/18/24.
//

import Foundation
import UIKit


struct Animal{
    var name:String?
    var information:String?
    var imageName:UIImage?
}


let lion = Animal(name: "Lion", information: "Lions are large carnivorous mammals and are known as the 'king of the jungle'. They are highly social animals and live in groups called prides.", imageName:  UIImage(named: "lion"))

let elephant = Animal(name: "Elephant", information: "Elephants are the largest land animals on Earth. They are known for their long trunk, large ears, and tusks. Elephants are highly intelligent and exhibit complex social behaviors.", imageName: UIImage(named:"elephant"))

let tiger = Animal(name: "Tiger", information: "Tigers are the largest cat species and are known for their distinctive orange coat with black stripes. They are solitary animals and are powerful hunters.", imageName: UIImage(named:"tiger"))

let giraffe = Animal(name: "Giraffe", information: "Giraffes are the tallest land animals, with long necks and legs. They are herbivores and feed on leaves from trees. Giraffes have distinctive spotted patterns on their coat.", imageName: UIImage(named:"giraffe"))

let zebra = Animal(name: "Zebra", information: "Zebras are known for their black and white striped coats. They are herbivores and live in groups called herds. Zebras are native to Africa.", imageName: UIImage(named:"zebra"))

let panda = Animal(name: "Panda", information: "Pandas are large bears native to China. They are known for their distinctive black and white fur. Pandas primarily feed on bamboo and are endangered.", imageName: UIImage(named:"panda"))

let koala = Animal(name: "Koala", information: "Koalas are marsupials native to Australia. They are known for their fluffy ears and diet consisting mainly of eucalyptus leaves. Koalas are arboreal and spend most of their time in trees.", imageName: UIImage(named:"koala"))

let dolphin = Animal(name: "Dolphin", information: "Dolphins are highly intelligent marine mammals known for their playful behavior and communication skills. They are social animals and often travel in pods.", imageName: UIImage(named:"dolphin"))

let penguin = Animal(name: "Penguin", information: "Penguins are flightless birds found primarily in the Southern Hemisphere, especially in Antarctica. They have a distinctive black and white plumage and are excellent swimmers.", imageName: UIImage(named:"penguin"))

let polarBear = Animal(name: "Polar Bear", information: "Polar bears are large carnivorous mammals native to the Arctic region. They are superb swimmers and primarily feed on seals. Polar bears are threatened by climate change.", imageName: UIImage(named:"polarbear"))

let kangaroo = Animal(name: "Kangaroo", information: "Kangaroos are marsupials native to Australia. They are known for their powerful hind legs and pouch used to carry their young, called joeys.", imageName: UIImage(named:"kangaroo"))

let gorilla = Animal(name: "Gorilla", information: "Gorillas are large primates native to Africa. They are known for their strength and intelligence. Gorillas live in groups called troops and are primarily herbivorous.", imageName: UIImage(named:"gorilla"))

let wolf = Animal(name: "Wolf", information: "Wolves are carnivorous mammals native to various parts of the world. They are highly social animals and live in packs. Wolves are skilled hunters and play a vital role in their ecosystems.", imageName: UIImage(named:"wolf"))

let cheetah = Animal(name: "Cheetah", information: "Cheetahs are the fastest land animals, capable of reaching speeds up to 60 miles per hour in short bursts. They are skilled hunters and primarily prey on small to medium-sized ungulates.", imageName: UIImage(named:"cheetah"))

let crocodile = Animal(name: "Crocodile", information: "Crocodiles are large aquatic reptiles found in tropical regions. They are apex predators and have a powerful bite. Crocodiles are ambush hunters and primarily feed on fish, birds, and mammals.", imageName: UIImage(named:"crocodile"))


let animals:[Animal] = [lion,elephant,tiger,giraffe,zebra,panda,koala,dolphin,penguin,polarBear,kangaroo,gorilla,wolf,cheetah,crocodile]
