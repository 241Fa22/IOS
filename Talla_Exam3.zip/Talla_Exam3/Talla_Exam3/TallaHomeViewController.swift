//
//  ViewController.swift
//  Talla_Exam3
//
//  Created by Divya Talla on 4/18/24.
//

import UIKit

class TallaHomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TallaCell", for: indexPath)
        
        let animal = animals[indexPath.row] // Access the Animal object at the current index
        
        // Assuming 'name' is the property of Animal that holds the name of the animal
        cell.textLabel?.text = animal.name
        
        return cell
    }
    
  
    

    @IBOutlet weak var TallaTVOL: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        title = "Animals"
        TallaTVOL.dataSource = self
        TallaTVOL.delegate = self
             
             
    
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//          performSegue(withIdentifier: "TallaDescriptionSegue", sender: indexPath.row)
      }
      
      // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "TallaDescriptionSegue",
           let animalVC = segue.destination as? TallaAnimalController,
           let selectedAnimal = sender as? Animal {
            animalVC.animalName = selectedAnimal.name
        }
    }




}

