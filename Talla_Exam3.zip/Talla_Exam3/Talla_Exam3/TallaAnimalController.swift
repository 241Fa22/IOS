//
//  TallaAnimalController.swift
//  Talla_Exam3
//
//  Created by Divya Talla on 4/18/24.
//

import UIKit

class TallaAnimalController: UIViewController {
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    
    @IBOutlet weak var descriptionOL: UITextView!
    
    
    var animalName: String?
       
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        title = animalName
                
                // Load animal details
                if let animal = animalName {
                    imageViewOL.image = UIImage(named: animal.lowercased())
                    nameOL.text = animal
                    descriptionOL.text = getDescription(for: animal)
                }
            }

    }
// Function to get the description for the given animal name
func getDescription(for animal: String) -> String? {
    if let animalObject = animals.first(where: { $0.name == animal }) {
        return animalObject.information
    }
    return nil
}

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


