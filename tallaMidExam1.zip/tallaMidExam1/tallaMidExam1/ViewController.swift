//
//  ViewController.swift
//  tallaMidExam1
//
//  Created by Divya Talla on 2/15/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var patientID: UITextField!
    
    
    @IBOutlet weak var fbgValue: UITextField!
    
        
    @IBOutlet weak var patientid: UILabel!
    
        
    @IBOutlet weak var fbgLevel: UILabel!
    
    
    @IBOutlet weak var HbAlc: UILabel!
    
    @IBOutlet weak var result: UILabel!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var healhtip: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calculateHbA1c(_ sender: Any) {
        
        guard let fbgText = fbgValue.text,
              let fbg = Double(fbgText)
        else {
            return
            
                
            }

           
            let hba1c = 2.6 + 0.03 * fbg
            
            // Determine the appropriate result based on HbA1c range
            var result = ""
            var healthTip = ""
            var imageName = ""
            
            if hba1c < 4.7 {
                result = "Hypoglycemia"
                print(healthTip = "Eat food on time 🍎")
                
                imageOL.image = UIImage(named: "hypoglycemia.jpeg")

            } else if hba1c >= 4.7 && hba1c <= 5.6 {
                result = "Normal"
               print( healthTip = "You are doing great 👍")
                imageOL.image = UIImage(named: "Normal.jpeg")

            } else if hba1c >= 5.61 && hba1c <= 6.35 {
                result = "Pre-Diabetes"
                healthTip = "You should work on your diet and maintain workout 🏋️"
                imageOL.image = UIImage(named: "prediabetes.jpeg")
            } else {
                result = "Diabetes"
                healthTip = "Consult doctor for medication 🩺"
                imageOL.image = UIImage(named: "diabetes.jpeg")
            }
            
        patientid.text = "PatientID: \(patientID.text ?? "")"
        fbgLevel.text = "FBG Level: \(fbgText)"
        hba1c.text = "HbA1c: \(String(format: "%.2f", hba1c))%"
        result.text = "Result: \(result)"
        healthTip.text = "Health Tip: \(healthTip)"
           

            
    }
    
   
    @IBAction func resetBTN(_ sender: Any) {
    }
    // Reset all fields
           
            patientidLabel.text = ""
            fbgLevelLabel.text = ""
            hba1cLabel.text = ""
            resultLabel.text = ""
            healthTipLabel.text = ""
        }
      
    
    











        

       
       




        
        
        
        
        
       
    
  

