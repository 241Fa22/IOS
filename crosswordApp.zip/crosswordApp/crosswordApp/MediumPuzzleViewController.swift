//
//  MediumPuzzleViewController.swift
//  crosswordApp
//
//  Created by Andrea F on 4/6/24.
//

import UIKit

class MediumPuzzleViewController: UIViewController {
    
    
    @IBOutlet weak var timerOL: UILabel!
    
    @IBOutlet weak var hintOL: UIButton!
    
    @IBOutlet weak var cluesOL: UILabel!
    
    @IBOutlet weak var A3: UITextField!
    
    @IBOutlet weak var A4: UITextField!
    
    @IBOutlet weak var A5: UITextField!
    
    @IBOutlet weak var B1: UITextField!
    
    @IBOutlet weak var B2: UITextField!
    
    @IBOutlet weak var B3: UITextField!
    
    @IBOutlet weak var B4: UITextField!
    
    @IBOutlet weak var B5: UITextField!
    
    @IBOutlet weak var C1: UITextField!
    
    @IBOutlet weak var C2: UITextField!
    
    @IBOutlet weak var C3: UITextField!
    
    @IBOutlet weak var C4: UITextField!
    
    @IBOutlet weak var C5: UITextField!
    
    @IBOutlet weak var D1: UITextField!
    
    @IBOutlet weak var D2: UITextField!
    
    @IBOutlet weak var D3: UITextField!
    
    @IBOutlet weak var D4: UITextField!
    
    @IBOutlet weak var D5: UITextField!
    
    @IBOutlet weak var E1: UITextField!
    
    @IBOutlet weak var E2: UITextField!
    
    @IBOutlet weak var E3: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func hintBtnClicked(_ sender: Any) {
    }
    
    @IBAction func A3Edited(_ sender: Any) {
    }
    
    @IBAction func A4Edited(_ sender: Any) {
    }
    
    @IBAction func A5Edited(_ sender: Any) {
    }
    
    @IBAction func B1Edited(_ sender: Any) {
    }
    
    @IBAction func B2Edited(_ sender: Any) {
    }
    
    @IBAction func B3Edited(_ sender: Any) {
    }
    
    @IBAction func B4Edited(_ sender: Any) {
    }
    
    @IBAction func B5Edited(_ sender: Any) {
    }
    
    @IBAction func C1Edited(_ sender: Any) {
    }
    
    @IBAction func C2Edited(_ sender: Any) {
    }
    
    @IBAction func C3Edited(_ sender: Any) {
    }
    
    @IBAction func C4Edited(_ sender: Any) {
    }
    
    @IBAction func C5Edited(_ sender: Any) {
    }
    
    @IBAction func D1Edited(_ sender: Any) {
    }
    
    @IBAction func D2Edited(_ sender: Any) {
    }
    
    @IBAction func D3Edited(_ sender: Any) {
    }
    
    @IBAction func D4Edited(_ sender: Any) {
    }
    
    @IBAction func D5Edited(_ sender: Any) {
    }
    
    @IBAction func E1Edited(_ sender: Any) {
    }
    
    @IBAction func E2Edited(_ sender: Any) {
    }
    
    @IBAction func E3Edited(_ sender: Any) {
    }
    
    @IBAction func checkBtnClicked(_ sender: Any) {
    }
    
    
    
    //override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    // Get the new view controller using segue.destination.
    // Pass the selected object to the new view controller.
    
}
