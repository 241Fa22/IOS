//
//  ViewController.swift
//  crosswordApp
//
//  Created by Andrea F on 4/4/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOL: UITextField!
    
 
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func easyBtn(_ sender: Any) {
    }
    
    @IBAction func mediumBtn(_ sender: Any) {
    }
    @IBAction func hardBtn(_ sender: Any) {
    }
}

