//
//  DetailCollectionViewCell.swift
//  Talla_PracticeExam2
//
//  Created by Divya Talla on 4/9/24.
//

import UIKit

class DetailCollectionViewCell: UICollectionViewCell {
    var loanType: String = ""
        var loanAmount: Double = 0
        var interestRate: Double = 0
        var term: Int = 0
        var monthlyEMIPayment: Double = 0
    
    @IBOutlet weak var LoanType: UILabel!
    
    
    @IBOutlet weak var EnteredLoanAmount: UILabel!
    
    @IBOutlet weak var EnteredInterestRate: UILabel!
    
    
    @IBOutlet weak var CalcMonthlyEmi: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
   
        
        func displayData() {
            LoanType.text = "Loan Type: \(loanType)"
            EnteredLoanAmount.text = "Entered Loan Amount: \(loanAmount)"
            EnteredInterestRate.text = "Entered Interest Rate: \(interestRate)%"
            CalcMonthlyEmi.text = String(format: "Calculated Monthly EMI Amount: %.2f", monthlyEMIPayment)
            
            // Set image based on loan type
            switch loanType.lowercased() {
            case "car":
                imageView.image = UIImage(named: "Car")
            case "personal":
                imageView.image = UIImage(named: "Personal")
            case "home":
                imageView.image = UIImage(named: "Home")
            default:
                break
            }
        }

}
