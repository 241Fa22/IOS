//
//  GroceriesViewController.swift
//  Talla_Groceries
//
//  Created by Divya Talla on 4/15/24.
//

import UIKit

class GroceriesViewController: UIViewController {
    
    @IBOutlet var itemCollectionView: UIView!
    
    @IBOutlet weak var itemNameLabel: UILabel!
    
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    
    @IBOutlet weak var itemExpireLabel: UILabel!
    
    
    @IBOutlet weak var itemDescriptionLabel: UILabel!
    
    
    @IBOutlet weak var itemQualityLabel: UILabel!
    
    
    @IBOutlet weak var itemOriginLabel: UILabel!
    
    
    @IBOutlet weak var UIImage: UIImageView!
    
    var selectedItem: Item?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        if let item = selectedItem {
            populateItemDetails(item)
        }
        
    }
    func populateItemDetails(_ item: Item) {
        itemNameLabel.text = item.itemName
        itemPriceLabel.text = "\(item.itemPrice)"
        itemExpireLabel.text = item.itemExpiry
        itemDescriptionLabel.text = item.itemDescription
        itemQualityLabel.text = "\(item.itemQuantity)"
        itemOriginLabel.text = item.itemOrigin
        UIImage.image = item.image    
}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
