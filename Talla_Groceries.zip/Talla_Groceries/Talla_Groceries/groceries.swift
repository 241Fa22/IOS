//
//  groceries.swift
//  Talla_Groceries
//
//  Created by Divya Talla on 4/15/24.
//

import Foundation
import UIKit
// Generate Data
struct Item {
    let itemName: String
    let image: UIImage
    let itemPrice: Double
    let itemExpiry: String
    let itemQuantity: Int
    let itemOrigin: String
    let itemDescription: String
}
//fruits
let category1: [Fruits] = [
    Item(itemName: "Banana", image: UIImage(named: "Banana")!, itemPrice: 1.29, itemExpiry: "2024-04-12", itemQuantity: 12, itemOrigin: "California", itemDescription: "Ripe yellow bananas"),
    Item(itemName: "Apple", image: UIImage(named: "Apple")!, itemPrice: 3.66, itemExpiry: "2024-04-12", itemQuantity: 2, itemOrigin: "California", itemDescription: "Fresh and juicy apples"),
    Item(itemName: "Oranges", image: UIImage(named: "orange")!, itemPrice: 1.49, itemExpiry: "2024-04-14", itemQuantity: 10, itemOrigin: "Florida", itemDescription: "Sweet and tangy oranges"),
       Item(itemName: "Grapes", image: UIImage(named: "grapes")!, itemPrice: 2.99, itemExpiry: "2024-04-13", itemQuantity: 8, itemOrigin: "California", itemDescription: "Fresh red grapes"),
       Item(itemName: "Strawberries", image: UIImage(named: "strawberry")!, itemPrice: 3.99, itemExpiry: "2024-04-11", itemQuantity: 6, itemOrigin: "Florida", itemDescription: "Plump ripe strawberries"),
       Item(itemName: "Blueberries", image: UIImage(named: "blueberry")!, itemPrice: 4.99, itemExpiry: "2024-04-15", itemQuantity: 8, itemOrigin: "Michigan", itemDescription: "Juicy blueberries"),
       Item(itemName: "Pineapple", image: UIImage(named: "pineapple")!, itemPrice: 2.79, itemExpiry: "2024-04-16", itemQuantity: 1, itemOrigin: "Hawaii", itemDescription: "Fresh pineapple"),
       Item(itemName: "Watermelon", image: UIImage(named: "watermelon")!, itemPrice: 5.99, itemExpiry: "2024-04-10", itemQuantity: 1, itemOrigin: "Georgia", itemDescription: "Sweet seedless watermelon"),
       Item(itemName: "Mangoes", image: UIImage(named: "mango")!, itemPrice: 2.49, itemExpiry: "2024-04-14", itemQuantity: 6, itemOrigin: "Mexico", itemDescription: "Ripe and juicy mangoes"),
       Item(itemName: "Peaches", image: UIImage(named: "peach")!, itemPrice: 1.79, itemExpiry: "2024-04-12", itemQuantity: 8, itemOrigin: "Georgia", itemDescription: "Sweet and fuzzy peaches"),
   
]
    //dairy
let category2: [Dairy] = [
    Item(itemName: "Eggs", image: UIImage(named: "Eggs")!, itemPrice: 4.19, itemExpiry: "2024-04-12", itemQuantity: 12, itemOrigin: "California", itemDescription: "Farm-fresh organic egg"),
    Item(itemName: "Milk", image: UIImage(named: "Milk")!, itemPrice: 1.29, itemExpiry: "2024-04-12", itemQuantity: 12, itemOrigin: "California", itemDescription: "Fresh whole milk"),
    Item(itemName: "Butter", image: UIImage(named: "butter")!, itemPrice: 3.99, itemExpiry: "2024-04-20", itemQuantity: 1, itemOrigin: "Local Dairy Farm", itemDescription: "Creamy unsalted butter"),
        Item(itemName: "Cheese", image: UIImage(named: "cheese")!, itemPrice: 3.79, itemExpiry: "2024-04-20", itemQuantity: 1, itemOrigin: "Artisan Cheese Maker", itemDescription: "Aged cheddar cheese block"),
        Item(itemName: "Yogurt", image: UIImage(named: "yogurt")!, itemPrice: 2.29, itemExpiry: "2024-04-17", itemQuantity: 1, itemOrigin: "Local Dairy Farm", itemDescription: "Creamy Greek yogurt"),
        Item(itemName: "Sour Cream", image: UIImage(named: "sour_cream")!, itemPrice: 1.99, itemExpiry: "2024-04-15", itemQuantity: 1, itemOrigin: "Local Dairy Farm", itemDescription: "Rich sour cream"),
        Item(itemName: "Cottage Cheese", image: UIImage(named: "cottage_cheese")!, itemPrice: 2.49, itemExpiry: "2024-04-18", itemQuantity: 1, itemOrigin: "Local Dairy Farm", itemDescription: "Creamy cottage cheese"),
        Item(itemName: "Heavy Cream", image: UIImage(named: "heavy_cream")!, itemPrice: 4.29, itemExpiry: "2024-04-19", itemQuantity: 1, itemOrigin: "Local Dairy Farm", itemDescription: "Rich heavy cream"),
        Item(itemName: "Mozzarella", image: UIImage(named: "mozzarella")!, itemPrice: 3.99, itemExpiry: "2024-04-22", itemQuantity: 1, itemOrigin: "Artisan Cheese Maker", itemDescription: "Fresh mozzarella cheese"),
        Item(itemName: "Feta Cheese", image: UIImage(named: "feta_cheese")!, itemPrice: 5.49, itemExpiry: "2024-04-25", itemQuantity: 1, itemOrigin: "Artisan Cheese Maker", itemDescription: "Crumbly feta cheese")
    //Add more Items as needed.
]


    
//vegitables
let category3: [Vegetables] = [
    Item(itemName: "Tomatoes", image: UIImage(named: "tomatoes")!, itemPrice: 1.99, itemExpiry: "2024-04-10", itemQuantity: 6, itemOrigin: "Local Farm", itemDescription: "Fresh ripe tomatoes"),
    Item(itemName: "Potatoes", image: UIImage(named: "potatoes")!, itemPrice: 0.89, itemExpiry: "2024-04-14", itemQuantity: 10, itemOrigin: "Idaho", itemDescription: "Organic russet potatoes"),
    Item(itemName: "Carrots", image: UIImage(named: "carrots")!, itemPrice: 1.29, itemExpiry: "2024-04-12", itemQuantity: 8, itemOrigin: "Local Farm", itemDescription: "Fresh crunchy carrots"),
    Item(itemName: "Broccoli", image: UIImage(named: "broccoli")!, itemPrice: 1.79, itemExpiry: "2024-04-13", itemQuantity: 4, itemOrigin: "Local Farm", itemDescription: "Fresh broccoli florets"),
    Item(itemName: "Lettuce", image: UIImage(named: "lettuce")!, itemPrice: 1.49, itemExpiry: "2024-04-14", itemQuantity: 1, itemOrigin: "Local Farm", itemDescription: "Crisp iceberg lettuce"),
    Item(itemName: "Spinach", image: UIImage(named: "spinach")!, itemPrice: 1.99, itemExpiry: "2024-04-16", itemQuantity: 2, itemOrigin: "Local Farm", itemDescription: "Fresh baby spinach leaves"),
    Item(itemName: "Bell Peppers", image: UIImage(named: "bell_pepper")!, itemPrice: 1.69, itemExpiry: "2024-04-15", itemQuantity: 4, itemOrigin: "Local Farm", itemDescription: "Assorted bell peppers"),
    Item(itemName: "Cucumbers", image: UIImage(named: "cucumber")!, itemPrice: 0.99, itemExpiry: "2024-04-17", itemQuantity: 3, itemOrigin: "Local Farm", itemDescription: "Fresh crisp cucumbers"),
    Item(itemName: "Onions", image: UIImage(named: "onion")!, itemPrice: 0.79, itemExpiry: "2024-04-11", itemQuantity: 5, itemOrigin: "Local Farm", itemDescription: "Sweet yellow onions"),
    Item(itemName: "Garlic", image: UIImage(named: "garlic")!, itemPrice: 0.69, itemExpiry: "2024-04-10", itemQuantity: 3, itemOrigin: "Local Farm", itemDescription: "Fresh garlic bulbs"),

]//Nuts
let category4: [Nuts] = [
    Item(itemName: "Rice", image: UIImage(named: "rice")!, itemPrice: 2.99, itemExpiry: "2024-04-30", itemQuantity: 1, itemOrigin: "India", itemDescription: "Long grain Basmati rice"),
    Item(itemName: "Quinoa", image: UIImage(named: "quinoa")!, itemPrice: 4.99, itemExpiry: "2024-04-30", itemQuantity: 1, itemOrigin: "Peru", itemDescription: "Organic white quinoa"),
    Item(itemName: "Oats", image: UIImage(named: "oats")!, itemPrice: 3.49, itemExpiry: "2024-05-05", itemQuantity: 1, itemOrigin: "Canada", itemDescription: "Whole grain rolled oats"),
    Item(itemName: "Whole Wheat Bread", image: UIImage(named: "whole_wheat_bread")!, itemPrice: 2.79, itemExpiry: "2024-04-30", itemQuantity: 1, itemOrigin: "Local Bakery", itemDescription: "Nutritious whole wheat bread"),
    Item(itemName: "Pasta", image: UIImage(named: "pasta")!, itemPrice: 1.99, itemExpiry: "2024-05-10", itemQuantity: 1, itemOrigin: "Italy", itemDescription: "Imported Italian pasta"),
    Item(itemName: "Brown Rice", image: UIImage(named: "brown_rice")!, itemPrice: 3.29, itemExpiry: "2024-05-05", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Whole grain brown rice"),
    Item(itemName: "Barley", image: UIImage(named: "barley")!, itemPrice: 2.49, itemExpiry: "2024-05-08", itemQuantity: 1, itemOrigin: "Canada", itemDescription: "Pearled barley grains"),
    Item(itemName: "Couscous", image: UIImage(named: "couscous")!, itemPrice: 2.99, itemExpiry: "2024-05-10", itemQuantity: 1, itemOrigin: "Morocco", itemDescription: "Traditional Moroccan couscous"),
    Item(itemName: "Buckwheat", image: UIImage(named: "buckwheat")!, itemPrice: 3.49, itemExpiry: "2024-05-12", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Whole grain buckwheat groats"),
    Item(itemName: "Millet", image: UIImage(named: "millet")!, itemPrice: 2.99, itemExpiry: "2024-05-15", itemQuantity: 1, itemOrigin: "India", itemDescription: "Nutty flavored millet grains"),
]
//meat
let category5: [Meat] = [
    Item(itemName: "Chicken Breast", image: UIImage(named: "chicken_breast")!, itemPrice: 5.99, itemExpiry: "2024-04-16", itemQuantity: 1, itemOrigin: "Local Farm", itemDescription: "Fresh organic chicken breast"),
    Item(itemName: "Salmon Fillet", image: UIImage(named: "salmon_fillet")!, itemPrice: 8.99, itemExpiry: "2024-04-13", itemQuantity: 1, itemOrigin: "Alaska", itemDescription: "Wild-caught Alaskan salmon fillet"),
    Item(itemName: "Ground Beef", image: UIImage(named: "ground_beef")!, itemPrice: 6.49, itemExpiry: "2024-04-17", itemQuantity: 1, itemOrigin: "Local Farm", itemDescription: "Lean ground beef"),
    Item(itemName: "Shrimp", image: UIImage(named: "shrimp")!, itemPrice: 9.99, itemExpiry: "2024-04-15", itemQuantity: 1, itemOrigin: "Gulf of Mexico", itemDescription: "Jumbo wild-caught shrimp"),
    Item(itemName: "Pork Chops", image: UIImage(named: "pork_chops")!, itemPrice: 7.49, itemExpiry: "2024-04-14", itemQuantity: 1, itemOrigin: "Local Farm", itemDescription: "Tender pork chops"),
    Item(itemName: "Tilapia Fillet", image: UIImage(named: "tilapia_fillet")!, itemPrice: 6.99, itemExpiry: "2024-04-19", itemQuantity: 1, itemOrigin: "Local Fishery", itemDescription: "Fresh tilapia fillet"),
    Item(itemName: "Lamb Chops", image: UIImage(named: "lamb_chops")!, itemPrice: 10.99, itemExpiry: "2024-04-18", itemQuantity: 1, itemOrigin: "Local Farm", itemDescription: "Succulent lamb chops"),
    Item(itemName: "Cod Fillet", image: UIImage(named: "cod_fillet")!, itemPrice: 8.49, itemExpiry: "2024-04-22", itemQuantity: 1, itemOrigin: "North Atlantic", itemDescription: "Fresh cod fillet"),
    Item(itemName: "Ground Turkey", image: UIImage(named: "ground_turkey")!, itemPrice: 5.99, itemExpiry: "2024-04-20", itemQuantity: 1, itemOrigin: "Local Farm", itemDescription: "Lean ground turkey"),
    Item(itemName: "Sausages", image: UIImage(named: "sausages")!, itemPrice: 4.99, itemExpiry: "2024-04-25", itemQuantity: 1, itemOrigin: "Local Butcher", itemDescription: "Juicy pork sausages"),
]
// Add more categories.......


// Array to store categories along with their respective item lists to retrieve data in collection view.
let allCategories: [[Item]] = [category1,category2,category3,category4,category5]


// Array to store all category names to display in the table view and as title in the second view.
let categoryNames: [String] = ["Fruits","Dairy","Bakery","Nuts","Meat"]
    

