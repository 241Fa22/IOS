//
//  ViewController.swift
//  Talla_Groceries
//
//  Created by Divya Talla on 4/15/24.
//

import UIKit

class CategoriesViewController: UIViewController,UICollectionViewDataSource,UITableViewDataSource, UITableViewDelegate{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categories.count

    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "categoryCollectionCell", for: indexPath) as! CategoryCollectionViewCell
        cell.categoryLabel.text = categories[indexPath.item]
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories.count

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "categoryCell", for: indexPath)
        cell.textLabel?.text = categories[indexPath.row]
        return cell
    }
    
   
    
    
    
    @IBOutlet weak var categoryTableViewOL: UITableView!
    
    
    
    let categories = ["Fruits", "Vegetables", "Dairy", "Nuts", "Meats"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        categoryTableViewOL.dataSource = self
        categoryTableViewOL.delegate = self
        
        
    }
        
        // MARK: - Navigation
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "groceriesSegue" {
                if let groceriesVC = segue.destination as? GroceriesViewController, let category = sender as? String {
                    groceriesVC.categoryName = category
                
                        }
                    }
                }
            
            
        }
