//
//  ItemCollectionViewCell.swift
//  Talla_Groceries
//
//  Created by Divya Talla on 4/15/24.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
}
