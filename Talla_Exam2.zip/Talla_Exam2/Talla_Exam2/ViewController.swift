//
//  ViewController.swift
//  Talla_Exam2
//
//  Created by Divya Talla on 4/11/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var patientIdOL: UITextField!
    
    @IBOutlet weak var SystolicOL: UITextField!
    
    @IBOutlet weak var diastolicOL: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }

    @IBAction func checkBloodpreesureBtn(_ sender: Any) {
        guard let patientId = patientIdOL.text,
                     let systolicText = SystolicOL.text,
                     let diastolicText = diastolicOL.text,
                     let systolic = Double(systolicText),
                     let diastolic = Double(diastolicText) else {
                   // Handle invalid input
                   return
               }
               
               let meanBloodPressure = calculateMBP(systolic: systolic, diastolic: diastolic)
               let result = determineResult(mbp: meanBloodPressure)
               let healthTip = getHealthTip(result: result)
               
               performSegue(withIdentifier: "resultSegue", sender: (patientId, meanBloodPressure, result, healthTip))
           }
           
           private func calculateMBP(systolic: Double, diastolic: Double) -> Double {
               return (0.667 * diastolic) + (0.334 * systolic)
           }
           
           private func determineResult(mbp: Double) -> String {
               if mbp < 60 {
                   return "Stroke or Internal Bleeding"
               } else if mbp < 70 {
                   return "Hypotension"
               } else if mbp < 100 {
                   return "Good Health"
               } else if mbp < 107 {
                   return "Elevated"
               } else {
                   return "Hypertension"
               }
           }
           
           private func getHealthTip(result: String) -> String {
               switch result {
               case "Stroke or Internal Bleeding":
                   return "Seek immediate medical Attention. 👨🏻‍⚕️"
               case "Hypotension":
                   return "Stay Hydrated 🥛"
               case "Good Health":
                   return "You are doing great 👍"
               case "Elevated":
                   return "Make sure to maintain workout 🏋️"
               case "Hypertension":
                   return "Consult doctor for medication tab 💊"
               default:
                   return ""
               }
           }
           
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "resultSegue", let destination = segue.destination as? ResultViewController {
            if let data = sender as? (String, Double, String, String) {
                destination.patientIdValue = data.0
                destination.meanBloodPressureValue = data.1
                destination.resultValue = data.2
                destination.healthTipValue = data.3
            } else {
                print("Error: Failed to extract sender data")
            }
        } else {
            print("Error: Invalid segue identifier")
        }
    }
        
    

               }
           
       
    
    


