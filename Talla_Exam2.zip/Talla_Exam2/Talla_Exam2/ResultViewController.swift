//
//  ResultViewController.swift
//  Talla_Exam2
//
//  Created by Divya Talla on 4/11/24.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var imageView: UIImageView!
    
    
    @IBOutlet weak var patientId: UILabel!
    
    
    @IBOutlet weak var bloodPressure: UILabel!
    
    
    @IBOutlet weak var MBP: UILabel!
    
    
    @IBOutlet weak var result: UILabel!
    
    
    @IBOutlet weak var healthTip: UILabel!
    
    
       var patientIdValue: String?
       var meanBloodPressureValue: Double?
       var resultValue: String?
       var healthTipValue: String?
       
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        populateUI()

    }
    private func populateUI() {
            if let patientId = patientId {
                patientId.text = "Patient ID: \(patientId)"
            }
            
        if let meanBloodPressureValue = meanBloodPressureValue {
               bloodPressure.text = "Blood Pressure: \(meanBloodPressureValue) mm Hg"
           }
        
        
        if let resultValue = result{
               result.text = "Result: \(resultValue)"
            updateImage(for: "\(resultValue)") 

            
           }
            
            if let healthTip = healthTip {
                healthTip.text = "healthTip: \(healthTipValue)"
            }
        }
        
        private func updateImage(for result: String) {
            // You need to set appropriate images for different result cases
            // Here's an example of how you can update the image based on the result
            switch result {
            case "Stroke or Internal Bleeding":
                imageView.image = UIImage(named: "stroke")
            case "Hypotension":
                imageView.image = UIImage(named: "hypotension")
            case "Good Health":
                imageView.image = UIImage(named: "healthy")
            case "Elevated":
                imageView.image = UIImage(named: "elevated")
            case "Hypertension":
                imageView.image = UIImage(named: "hypertension")
            default:
                break
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

