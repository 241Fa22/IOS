//
//  ViewController.swift
//  Talla_PracticeExam2
//
//  Created by Divya Talla on 4/9/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var loanTypeOL: UITextField!
    
    
    @IBOutlet weak var loanAmountOL: UITextField!
    
    
    @IBOutlet weak var interestRateOL: UITextField!
    
    
    @IBOutlet weak var termsOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calculateEmiBtn(_ sender: Any) {
        guard let loanType = loanTypeOL.text,
              let loanAmountText = loanAmountOL.text,
              let interestRateText = interestRateOL.text,
              let termText = termsOL.text,
              let loanAmount = Double(loanAmountText),
              let interestRate = Double(interestRateText),
              let term = Int(termText) else {
            // Handle invalid input
            return
        }
        
        let totalMonths = term * 12
        let monthlyInterestRate = (interestRate / 12) / 100
        let monthlyEMIPayment = loanAmount * (monthlyInterestRate * pow(1 + monthlyInterestRate, Double(totalMonths))) / (pow(1 + monthlyInterestRate, Double(totalMonths)) - 1)
        
        // Perform segue and pass data to ResultViewController
               performSegue(withIdentifier: "operateSegue", sender: monthlyEMIPayment)
    }
    
    
    
    @IBAction func ResetBtn(_ sender: Any) {
        loanTypeOL.text = ""
        loanAmountOL.text = ""
        interestRateOL.text = ""
        termsOL.text = ""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "operateSegue",
           let destinationVC = segue.destination as? DetailCollectionViewCell,
           let monthlyEMIPayment = sender as? Double {
            // Pass data to the ResultViewController
            destinationVC.loanType = loanTypeOL.text ?? ""
            destinationVC.loanAmount = Double(loanAmountOL.text ?? "") ?? 0
            destinationVC.interestRate = Double(interestRateOL.text ?? "") ?? 0
            destinationVC.term = Int(termsOL.text ?? "") ?? 0
            destinationVC.monthlyEMIPayment = monthlyEMIPayment
            
        }
        
    }
}
