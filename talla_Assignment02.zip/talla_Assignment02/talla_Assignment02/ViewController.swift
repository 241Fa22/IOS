//
//  ViewController.swift
//  talla_Assignment02
//
//  Created by Divya Talla on 1/30/24.
//

import UIKit

class ViewController: UIViewController {


     
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    
    @IBOutlet weak var dateOutlet: UIDatePicker!
    
    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup
    }


    @IBAction func SubmitBTN(_ sender: Any) {
        let billAmounttext = billAmountOutlet.text!
               let tipPercentagetext = tipPercentageOutlet.text!
               guard let billAmount = Float(billAmounttext),
                         let tipPercentage = Float(tipPercentagetext)
        else {
                
                       return
                   }
               let datetime = dateOutlet.date
               let dateFormatter = DateFormatter()
               dateFormatter.dateFormat = "MM-dd-YYYY HH:mm:ss"
               dateLabel.text = dateFormatter.string(from: datetime)
               nameLabel.text = "Name: \(nameOutlet.text!)"
               billAmountLabel.text = "Bill Amount: $\(billAmount)"
               tipAmountLabel.text = "Tip Amount: $\(String(format: "%.2f", (tipPercentage*billAmount)/100))"
        
               let totalamount = String(format: "%.2f", (billAmount + (tipPercentage*billAmount)/100))
               
               totalAmountLabel.text = "Total Amount: $\(totalamount)"
        
        
        }
        
   
    @IBAction func ResetBTN(_ sender: Any) {
    
    nameOutlet.text = ""
               billAmountOutlet.text = ""
               tipPercentageOutlet.text = ""
               dateLabel.text = ""
               nameLabel.text = ""
               billAmountLabel.text = ""
               tipAmountLabel.text = ""
               totalAmountLabel.text = ""
        
    }
    
   


}

