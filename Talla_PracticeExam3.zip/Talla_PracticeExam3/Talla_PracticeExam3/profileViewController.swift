//
//  profileViewController.swift
//  Talla_PracticeExam3
//
//  Created by Divya Talla on 4/16/24.
//

import UIKit

class profileViewController: UIViewController {

    @IBOutlet weak var intialOL: UILabel!
    
    
    
    @IBOutlet weak var phoneNumberOL: UILabel!
    
    var contact: [String]?

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let contact = contactFile {
                    let firstName = contact[0]
                    let lastName = contact[1]
                    let phoneNumber = contact[2]
                    intialOL.text = "\(firstName.first ?? "-")\(lastName.first ?? "-")"
                    phoneNumberOL.text = phoneNumber
                }
            }
        }

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


