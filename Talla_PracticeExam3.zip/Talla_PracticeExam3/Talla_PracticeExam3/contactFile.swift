//
//  contactFile.swift
//  Talla_PracticeExam3
//
//  Created by Divya Talla on 4/16/24.
//

import Foundation
struct Contact {
    let firstName: String
    let lastName: String
    let phoneNumber: String
    
    init(firstName: String, lastName: String, phoneNumber: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.phoneNumber = phoneNumber
    }
}

// Sample data for contacts
let contacts: [Contact] = [
    Contact(firstName: "John", lastName: "Doe", phoneNumber: "123-456-7890"),
    Contact(firstName: "Jane", lastName: "Smith", phoneNumber: "987-654-3210"),
    Contact(firstName: "Alice", lastName: "Johnson", phoneNumber: "555-123-4567"),
    Contact(firstName: "Bob", lastName: "Jones", phoneNumber: "789-321-6540"),
    Contact(firstName: "Emily", lastName: "Brown", phoneNumber: "456-789-0123"),
    Contact(firstName: "David", lastName: "Wilson", phoneNumber: "321-987-6543"),
    Contact(firstName: "Sarah", lastName: "Davis", phoneNumber: "654-321-0987"),
    Contact(firstName: "Michael", lastName: "Miller", phoneNumber: "987-123-4567"),
    Contact(firstName: "Emma", lastName: "Garcia", phoneNumber: "123-789-4560"),
    Contact(firstName: "Christopher", lastName: "Martinez", phoneNumber: "456-123-7890")
]
