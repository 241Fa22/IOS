//
//  ViewController.swift
//  Talla_PracticeExam3
//
//  Created by Divya Talla on 4/16/24.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return contacts.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath)
               let contact = contacts[indexPath.row]
        cell.textLabel?.text = "\(contact.firstName) \(contact.lastName)"
               return cell
        
    }
    

    @IBOutlet weak var tableViewOL: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableViewOL.dataSource = self
        tableViewOL.delegate = self

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "contactSegue", sender: indexPath.row)
    }
    
    // MARK: - Navigation
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "contactSegue",
           let profileVC = segue.destination as? profileViewController,
           let selectedIndex = sender as? Int {
            let selectedContact = contacts[selectedIndex]
            let contactInfo = ["\(selectedContact.firstName) \(selectedContact.lastName)", selectedContact.phoneNumber]
            profileVC.contact = contactInfo
        }
    }

        }
    

            

        
    





