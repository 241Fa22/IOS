//
//  ViewController.swift
//  talla_practiceExam
//
//  Created by Divya Talla on 2/13/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var heightInFeet: UITextField!
    
    
    @IBOutlet weak var heightInInches: UITextField!
    
    
    @IBOutlet weak var weightInLbs: UITextField!
    
    
    @IBOutlet weak var displayLabel: UILabel!
    
    
    @IBOutlet weak var imageview: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func BTN(_ sender: Any) {
        
        //read input
        guard let heightFeetText = heightInFeet.text,
                     let heightInchesText = heightInInches.text,
                     let weightText = weightInLbs.text,
                     let heightFeet = Double(heightFeetText),
                     let heightInches = Double(heightInchesText),
                     let weight = Double(weightText)
        else {
                   displayLabel.text = "Invalid input"
                   return
               }
        let heightInInches = (heightFeet * 12) + heightInches
              
      

        let bmi = (703.0 * weight) / (heightInInches * heightInInches)


               let roundedBMI = String(format: "%.1f", bmi)
               displayLabel.text = "Your Body Mass Index is \(roundedBMI)"
               
               var category = ""
               var imageName = ""
               
               if bmi <= 18.5 {
                  
                   print("Your Body Mass Index is \(roundedBMI). This is considered \(category).")

                   imageview.image = UIImage(named: "underWeight.jpeg")

               } else if bmi <= 24.9 {
                   print("Your Body Mass Index is \(roundedBMI). This is considered \(category).")
                   imageview.image = UIImage(named: "normal.jpeg")
                   
               } else if bmi <= 29.9 {
                   print("Your Body Mass Index is \(roundedBMI). This is considered \(category).")

                   imageview.image = UIImage(named: "overWeight.jpeg")
               } else {
                   print("Your Body Mass Index is \(roundedBMI). This is considered \(category).")

                 imageview.image = UIImage(named: "obese.jpeg")
               }
               
               
            
           }
    
     
           
       }
       
        
    
    


//Underweight    <= 18.5
//Normal    18.6–24.9
//Overweight    25–29.9
//Obesity    BMI of 30 or greater

