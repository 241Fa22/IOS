
//  ViewController.swift
//  talla_SearchApp
//
//  Created by Divya Talla on 3/18/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    @IBOutlet weak var prevOL: UIButton!
    
    @IBOutlet weak var resetOL: UIButton!
    
    @IBOutlet weak var nextOL: UIButton!
    
    @IBOutlet weak var topicInfoText: UITextView!
 
    
    @IBOutlet weak var searchOL: UIButton!
    var imageNum = 0;
        var topic: Int = -1
        var count : Int = -1
        
        
        var arr = [["Mahesh babu","Nani","Prabhas","Ramcharan","Allu Arjun"],["roses","lilly","jasmine","sunflower","daisy"],["cat","lion","elephant","dog","zebra"]]
        var actors_keywords = ["Mahesh babu","Nani","Prabhas","Ramcharan","Allu Arjun","Actors","actors","actor","Actor","hero","film","movie","MOVIE","ACTOR","FILM","HERO","ACTORS"]
        
        var flowers_keywords = ["lilly","roses","jasmine","sunflower","daisy","garden","blossom","botany","flower","flowers","GARDEN","FLOWERS","FLOWER"]
        
        var animals_keywords = ["cat","lion","elephant","dog","zebra","animals","Animals","animal","zoo","wildlife","Animal","ANIMAL","ANIMALS"]
        
        var topics_array = [[
            "Mahesh Babu (born 9 August 1975) is an Indian actor, producer, media personality, and philanthropist who works mainly in Telugu cinema. He has appeared in more than 25 films, and won several accolades including, eight Nandi Awards, five Filmfare Telugu Awards, four SIIMA Awards, three CineMAA Awards, and one IIFA Utsavam Award. One of the highest-paid Telugu film actors.",
            "Ghanta Naveen Babu (born 24 February 1984), known professionally by his screen name Nani, is an Indian actor, producer, and television presenter known primarily for his work in Telugu cinema. Acclaimed for his versatile acting, he has received two Filmfare Awards and two Nandi Awards for his work.",
            "Uppalapati Venkata Suryanarayana Prabhas Raju born 23 October 1979) is an Indian actor who predominantly works in Telugu cinema. One of the highest-paid actors in Indian cinema, Prabhas has featured in Forbes India's Celebrity 100 list since 2015 and has received seven Filmfare Awards nominations, a Nandi Award, and a SIIMA Award.",
            " Konidela Ram Charan(born 27 March 1985) is an Indian actor, producer, and entrepreneur who primarily works in Telugu films. One of the highest-paid actors in Indian cinema, he is the recipient of three Filmfare Awards and two Nandi Awards. Since 2013, he has featured in Forbes India's Celebrity 100 list.",
            "Allu Arjun (born 8 April 1982) is an Indian actor known for his works mainly in Telugu cinema. One of the highest paid actors in India, Allu Arjun is also known for his dancing skills. He is a recipient of several awards including a National Film Award, six Filmfare Awards and three Nandi Awards. He has appeared in Forbes India's Celebrity 100 list since 2014. He is popularly referred to as Stylish Star"],
            ["A rose is either a woody perennial flowering plant of the genus Rosa in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars.They form a group of plants that can be erect shrubs, climbing, with stems that are often armed with sharp prickles. Their flowers vary in size and shape and are usually large and showy, in colours ranging from white through yellows and reds.",
                "Lillies are tall perennials ranging in height from 2–6 ft. They form naked or tunicless scaly underground bulbs which are their organs of perennation. In some North American species the base of the bulb develops into rhizomes, on which numerous small bulbs are found. Some species develop stolons. Most bulbs are buried deep in the ground, but a few species form bulbs near the soil surface.",
             "Jasmine is a genus of shrubs and vines in the olive family of Oleaceae.  It contains around 200 species native to tropical and warm temperate regions of Eurasia, Africa, and Oceania. Jasmines are widely cultivated for the characteristic fragrance of their flowers. Additionally a number of unrelated species of plants or flowers contain the word jasmine in their common names (see Other plants called jasmine).",
             "The common sunflower (Helianthus annuus) is a species of large annual forb of the genus Helianthus. It is commonly grown as a crop for its edible oily seeds. Apart from cooking oil production, it is also used as livestock forage (as a meal or a silage plant), as bird food, in some industrial applications, and as an ornamental in domestic gardens. Wild H. annuus is a widely branched annual plant with many flower heads. ",
            "Daisy is the common name for a large number of dicotyledonous flowering plants within the Asteraceae (or Composite) family, and in particular is associated with the true, common, or English daisy (Bellis perennis) and the oxeye daisy. Daisies are characterized by the star-shaped flower head, consisting of a densely packed cluster of numerous, small, individual flowers (florets). "],
            ["The cat commonly referred to as the domestic cat is the only domesticated species in the family Felidae.Recent advances in archaeology and genetics have shown that the domestication of the cat occurred in the Near East around 7500 BC.It is commonly kept as a house pet and farm cat,but also ranges freely as a feral cat avoiding human contact.",
             "The lion is a large cat of the genus Panthera native to Africa and India. It has a muscular, broad-chested body,short,round head,round ears and a hairy tuft at the end of its tail. It is sexually dimorphic,adult male lions are larger than females and have a prominent mane.A lion's pride consists of a few adult males, related females, and cubs. Groups of female lions usually hunt together mostly on large ungulates. ",
             "Elephants are the largest living land animals. Three living species:the African bush elephant, the African forest elephant,and the Asian elephant.They are the only surviving members of the family Elephantidae and the order Proboscidea; extinct relatives include mammoths and mastodons. Distinctive features of elephants include a trunk, tusks, large ear flaps, pillar-like legs, and tough but grey skin.",
             "The dog is a domesticated descendant of the wolf. Also called the domestic dog, it is derived from extinct Pleistocene wolves, and the modern wolf is the dog's nearest living relative. The dog was the first species to be domesticated by humans. Hunter-gatherers did this, over 15,000 years ago, which was before the development of agriculture.",
             "Zebras are African equines with distinctive black-and-white striped coats. There are three living species: the Grévy's zebra , plains zebra , and the mountain zebra.Zebras share the genus Equus with horses and asses, the three groups being the only living members of the family Equidae. Zebra stripes come in different patterns, unique to each individual. Several theories have been proposed for the function of these stripes."]]
        
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
               searchOL.isEnabled = false
               prevOL.isHidden = true
               nextOL.isHidden = true
               resetOL.isHidden = true
           
    }

   
    @IBAction func searchtextField(_ sender: Any) {
    
    if(searchTextField.text!.isEmpty)
              {
                  searchOL.isEnabled = false
              }
              else
              {
                  searchOL.isEnabled = true
              }
              
    }
    
    @IBAction func searchButtonAction(_ sender: Any) {
        searchOL.isEnabled = true
                let a = searchTextField.text!
                count = 0
                if(actors_keywords.contains(a)){
                    prevOL.isHidden = false
                    nextOL.isHidden = false
                    resetOL.isHidden = false
                    topicInfoText.isHidden = false;
                    topic = 0
                    resultImage.image = UIImage(named: arr[topic][count])
                    topicInfoText.text = topics_array[topic][count]
                    if(count==0){
                        prevOL.isEnabled = false
                        
                    }
                    else{
                        prevOL.isEnabled = true
                        
                    }
                    if(count == arr[topic].count-1){
                        nextOL.isEnabled = false
                        
                    }
                    else{
                        nextOL.isEnabled = true
                        
                    }
                    resetOL.isEnabled = true
                }
                else if(flowers_keywords.contains(a)){
                    prevOL.isHidden = false
                    nextOL.isHidden = false
                    resetOL.isHidden = false
                    topicInfoText.isHidden = false;
                    topic = 1
                    resultImage.image = UIImage(named: arr[topic][count])
                    topicInfoText.text = topics_array[topic][count]
                    if(count==0){
                        prevOL.isEnabled = false
                        
                    }
                    else{
                        prevOL.isEnabled = true
                        
                    }
                    if(count == arr[topic].count-1){
                        nextOL.isEnabled = false
                        
                    }
                    else{
                        nextOL.isEnabled = true
                        
                    }
                    resetOL.isEnabled = true
                }
               else if(animals_keywords.contains(a)){
                   prevOL.isHidden = false
                   nextOL.isHidden = false
                   resetOL.isHidden = false
                   topicInfoText.isHidden = false;
                    topic = 2
                   resultImage.image = UIImage(named: arr[topic][count])
                   topicInfoText.text = topics_array[topic][count]
                   if(count==0){
                       prevOL.isEnabled = false
                       
                   }
                   else{
                       prevOL.isEnabled = true
                       
                   }
                   if(count == arr[topic].count-1){
                       nextOL.isEnabled = false
                       
                   }
                   else{
                                 nextOL.isEnabled = true
                                 
                             }
                             resetOL.isEnabled = true
                          }
                          else if(!actors_keywords.contains(a) && !animals_keywords.contains(a) && !flowers_keywords.contains(a)){
                              topic = -1
                              resultImage.image = UIImage(named: "oops")
                              prevOL.isHidden = true
                              nextOL.isHidden = true
                              resetOL.isHidden = true
                              topicInfoText.isHidden = true;
                              
                          }
                          
    }
    
    @IBAction func ShowPrevImagesBTN(_ sender: Any) {
        count-=1
               resultImage.image = UIImage(named: arr[topic][count])
               topicInfoText.text = topics_array[topic][count]
               if(count==0){
                   prevOL.isEnabled = false
               }
               else{
                   prevOL.isEnabled = true
               }
               if(count == arr[topic].count-1){
                   nextOL.isEnabled = false
               }
               else{
                   nextOL.isEnabled = true
               }
               resetOL.isEnabled = true
           }
           
    
    
    @IBAction func ResetBTN(_ sender: Any) {
        searchTextField.text = ""
               searchOL.isEnabled = false
               
               prevOL.isHidden = true
               nextOL.isHidden = true
               resetOL.isHidden = true
               topicInfoText.text = ""
               resultImage.image = UIImage(named: "Welcome")
           }
    
    
    @IBAction func ShowNextImagesBTN(_ sender: Any) {
        count+=1
               resultImage.image = UIImage(named: arr[topic][count])
               topicInfoText.text = topics_array[topic][count]
               if(count==0){
                   prevOL.isEnabled = false
               }
               else{
                   prevOL.isEnabled = true
               }
               if(count == arr[topic].count-1){
                   nextOL.isEnabled = false
               }
               else{
                   nextOL.isEnabled = true
               }
               resetOL.isEnabled = true
           }
           
    }


